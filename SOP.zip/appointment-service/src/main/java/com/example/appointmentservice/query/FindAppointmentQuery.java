package com.example.appointmentservice.query;

public class FindAppointmentQuery {
}
