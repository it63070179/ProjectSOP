package com.example.loginservice.query;

public class FindUsersQuery {
}
