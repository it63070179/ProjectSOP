package register.query;

import lombok.Data;

@Data
public class FindByUsername {
    private String username;

    public FindByUsername(String username){
        this.username = username;
    }
}
