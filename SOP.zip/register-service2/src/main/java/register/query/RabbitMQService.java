package register.query;

import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import register.query.rest.UserRestModel;

@Service
public class RabbitMQService {
    @Autowired
    QueryGateway queryGateway;

    @RabbitListener(queues = "GetUserByUsernameAndPassword")
    public UserRestModel getUserByUsernameAndPassword(String username){
        System.out.println("GetUserByUsernameAndPassword");
        FindByUsername findByUsername = new FindByUsername(username);
        UserRestModel user;
        try{
            user = queryGateway.query(findByUsername, ResponseTypes.instanceOf(UserRestModel.class)).join();
        }catch (Exception e){
            user = null;
        }
        return user;
    }
}
