package register.query.rest;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

public class UserQueryController {

    @Autowired
    RabbitTemplate rabbitTemplate;

    @GetMapping
    public List<UserRestModel> getUser(){
        Object users = rabbitTemplate.convertSendAndReceive("LoginExchange", "getAllUser", "");
        return (List<UserRestModel>) users;
    }

    @GetMapping(value = "/{username}")
    public List<UserRestModel> getUserByUsername(@PathVariable String username){
        if(username == ""){
            return null;
        }
        Object user = rabbitTemplate.convertSendAndReceive("RegisterExchange", "getByUsernameAndPassword", username);
        return (List<UserRestModel>) user;
    }
}
