package com.example.userservice2.core.event;

import lombok.Data;

@Data
public class AddDoctorEvent {
//    private String id;
    private String email;
    private String role;
}
