package com.example.userservice2.query;

public class FindByUsernameAndPassword {
    private String username;
    private String password;

    public FindByUsernameAndPassword(String username, String password){
        this.username = username;
        this.password = password;
    }
}
