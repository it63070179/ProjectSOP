package com.example.userservice2.query;

public class FindUsersQuery {
}
