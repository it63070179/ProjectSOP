package com.example.userservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserService2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
