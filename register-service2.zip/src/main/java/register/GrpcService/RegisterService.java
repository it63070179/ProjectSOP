package register.GrpcService;

import com.proto.register.RegisterRequest;
import com.proto.register.RegisterResponse;
import com.proto.register.RegisterServiceGrpc;
import register.core.UserEntity;
import register.core.data.UserRepository;
import io.grpc.stub.StreamObserver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegisterService extends RegisterServiceGrpc.RegisterServiceImplBase {
    @Autowired
    private UserRepository userRepository;

    @Override
    public void register(RegisterRequest request, StreamObserver<RegisterResponse> responseStreamObserver){
        UserEntity user = new UserEntity();
        user.setId(request.getId());
        user.setName(request.getName());
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setEmail(request.getEmail());
        user.setGender(request.getGender());
        user.setRole(request.getRole());
        userRepository.save(user);

        RegisterResponse response = RegisterResponse.newBuilder()
                .setId(user.getId())
                .build();
        System.out.println("register service response: " + response);
        responseStreamObserver.onNext(response);
        responseStreamObserver.onCompleted();
    }
}
