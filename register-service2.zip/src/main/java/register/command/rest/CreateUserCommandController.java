package register.command.rest;

import com.proto.register.RegisterRequest;
import com.proto.register.RegisterResponse;
import com.proto.register.RegisterServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/user")
public class CreateUserCommandController {
    @PostMapping("/register")
    public String createUser(@RequestBody CreateUserRestModel model){
        System.out.println("test test");
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50055)
                .usePlaintext().build();

        RegisterServiceGrpc.RegisterServiceBlockingStub registerClient = RegisterServiceGrpc.newBlockingStub(channel);

        RegisterRequest request = RegisterRequest.newBuilder()
                .setId(UUID.randomUUID().toString())
                .setName(model.getName())
                .setUsername(model.getUsername())
                .setPassword(model.getPassword())
                .setEmail(model.getEmail())
                .setGender(model.getGender())
                .setRole(model.getRole())
                .build();

        RegisterResponse response = registerClient.register(request);

        channel.shutdown();

        return response.getId();
    }
}
