package register.query;

import register.core.UserEntity;
import register.core.data.UserRepository;
import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import register.query.rest.UserRestModel;

@Component
public class UserQueryHandler {

    private final UserRepository userRepository;

    public UserQueryHandler(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @QueryHandler
    UserRestModel findByUsernameAndPassword(FindByUsername query){
        UserRestModel userRest = new UserRestModel();
        UserEntity user = userRepository.findByUsername(query.getUsername());
        BeanUtils.copyProperties(user, userRest);
        return userRest;
    }
}
